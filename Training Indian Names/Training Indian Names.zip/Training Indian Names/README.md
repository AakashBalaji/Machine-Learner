# SpeakToMe: Using Speech Recognition with AVAudioEngine

Shows how to use SFSpeechRecognizer with AVAudioEngine to record what a user says and transcribe it into text.

## Requirements

### Build

Xcode 8.0 or later; iOS 10.0 SDK or later

### Runtime

iOS 10.0 or later on an iOS device

Copyright (C) 2016 Apple Inc. All rights reserved.
